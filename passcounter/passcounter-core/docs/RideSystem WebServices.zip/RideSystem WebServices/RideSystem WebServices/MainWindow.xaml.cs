﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RideSystem_WebServices
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            //New WS Client
            RideService.Client wsClient = new RideService.Client();
            
            //New WS Smart Client  USE THIS ONE
            RideService.SmartSyncServiceContractClient wsSmartClient = new RideService.SmartSyncServiceContractClient();

            //New Request Object
            RideService.VehicleSyncRequest wsRequest = new RideService.VehicleSyncRequest();

            //Ride Credentials
            wsRequest.RideCredential = new RideService.RideCredential();
            wsRequest.RideCredential.CompanyID = 5;
            wsRequest.RideCredential.Token = "OUMedical1";
            wsRequest.RideCredential.EmployeeID = 1;

            wsRequest.HistoricalDays = 0;
            wsRequest.Request = new RideService.RequestArgument();
            wsRequest.Request.RequestType = RideService.RequestArgumentRequestTypes.FullSync;
            
            //Request
            RideService.EmployeeVehicleResponse wsResponse = wsSmartClient.GetHandheldEmployeesAndVehicles(wsRequest);
            

        }
    }
}
